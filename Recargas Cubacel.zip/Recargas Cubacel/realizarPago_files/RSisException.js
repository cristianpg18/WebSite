/**
	Funciones javascript para la p�gina RSISEXception
	 
**/


	function imprimir() {
		window.print();
	}
	
	function submitirRespuestaPUCE() {
		document.puceForm.submit();
	}
	
	function load()
	{
		document.all.divImg.style.visibility="visible";
		document.all.divImgNoScript.style.visibility="hidden";
	}

var errores;